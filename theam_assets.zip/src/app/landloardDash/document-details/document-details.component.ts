import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-document-details',
  templateUrl: './document-details.component.html',
  styleUrls: ['./document-details.component.css']
})
export class DocumentDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
