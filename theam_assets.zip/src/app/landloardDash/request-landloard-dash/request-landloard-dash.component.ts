import { Component, OnInit } from '@angular/core';
import { LandlordService } from '../../_services/landlord.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder, FormGroup, FormControl, FormArray, Validators } from '@angular/forms';

@Component({
  selector: 'app-request-landloard-dash',
  templateUrl: './request-landloard-dash.component.html',
  styleUrls: ['./request-landloard-dash.component.css']
})
export class RequestLandloardDashComponent implements OnInit {
  data: any[] = [];
  searchForm: FormGroup;
  decline_data: any[];
  accept_data: string;
  accept_decline_data: any;
  config: any;
  info: {};
  acceptValue = false;
  declineValue = false;
  indexRow: number;
  options = ['Pending', 'Accepted', 'Declined'];
  constructor(private landlordService: LandlordService, public toastr: ToastrManager, private route: ActivatedRoute,
    private router: Router, private formBuilder: FormBuilder, ) {
    this.config = {
      itemsPerPage: 10,
      currentPage: 1,
      totalItems: this.data.length
    };
  }
  ngOnInit() {
    this.get_request_data();
    this.searchForm = this.formBuilder.group({
      searchData: [''],
      optionSelect: ['']
    })
  }
  get_request_data() {
    this.landlordService.get_request_data().subscribe((res: any) => {
      this.data = res;
      console.log(res);
    }, (error) => {
      console.log(error);
    });
  }
  pageChanged(event) {
    this.config.currentPage = event;
  }
  accept_decline_request_status(id, status) {
    this.info = { id: id, status: status };
    console.log(this.info);
    this.landlordService.accept_decline_request_status(this.info).subscribe((res: any) => {
      this.accept_decline_data = res;
      console.log(this.accept_decline_data);
      if (res.accept === true) {
        this.acceptValue = true;
        this.toastr.successToastr('Accepted!.', 'Success!');
        //this.get_request_data();
      }
      else if (res.decline === true) {
        this.declineValue = true;
        this.toastr.successToastr('Declined!.', 'Success!');
        // this.get_request_data();
      } else {
        this.toastr.errorToastr('Error in data  !!!.', 'Oops!');
      }
    }, (error) => {
      console.log(error);
    })

  }
  onOptionSelected(event) {
    console.log(event);
  }
  onSearch() {
    let res = this.searchForm.value;
    if (res.searchData == '' && res.optionSelect == null) {
      this.toastr.errorToastr('Please enter atleast one field for filter  !!!.', 'Oops!');
    }
    else {
      this.searchForm = new FormGroup({
        searchData: new FormControl(res.searchData),
        optionSelect: new FormControl(res.optionSelect)
      })
      console.log(this.searchForm.value);
      this.landlordService.searchRequestData(this.searchForm.value).subscribe((res: any) => {
        console.log(this.searchForm.value);
        console.log(res);
        this.data = res;
      });
    }
  }
  test(i: number) {
    this.indexRow = i;
    console.log(i);
  }
}
