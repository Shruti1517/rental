import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recurring-transaction',
  templateUrl: './recurring-transaction.component.html',
  styleUrls: ['./recurring-transaction.component.css']
})
export class RecurringTransactionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
